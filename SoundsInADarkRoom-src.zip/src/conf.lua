function love.conf(t)
    t.version = "0.10.2"                -- The LÖVE version this game was made for (string)
    t.window.title = "Sounds in a Dark Room"
end